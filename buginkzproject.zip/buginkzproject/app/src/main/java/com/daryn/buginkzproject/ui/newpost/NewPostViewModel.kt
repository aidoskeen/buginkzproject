package com.daryn.buginkzproject.ui.newpost

import android.arch.lifecycle.ViewModel

class NewPostViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
package com.daryn.buginkzproject.ui.search

import android.arch.lifecycle.ViewModel

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}